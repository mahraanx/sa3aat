<?php 
defined('_JEXEC') or 	die(); 
// Here the plugin values
//$html =vmText::_($group->custom_title) ; ?>
<div>
	<div class="product-fields-title"><?php echo $this->params->custom_specification_name1 ?></div>
	<div><?php echo $this->params->custom_specification_default1 ?></div>
	<div class="product-fields-title"><?php echo $this->params->custom_specification_name2 ?></div>
	<div><?php echo $this->params->custom_specification_default2 ?></div>
</div>