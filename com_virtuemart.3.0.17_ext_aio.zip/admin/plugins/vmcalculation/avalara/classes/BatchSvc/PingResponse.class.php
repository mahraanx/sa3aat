<?php
/**
 * PingResponse.class.php
 */

/**
 * 
 *
 * @author    Avalara
 * @copyright � 2004 - 2011 Avalara, Inc.  All rights reserved.
 * @package   Batch
 */
class PingResponse {
  private $PingResult; // PingResult

  public function setPingResult($value){$this->PingResult=$value;} // PingResult
  public function getPingResult(){return $this->PingResult;} // PingResult

}

?>
